# Invisible Touchpad Controller

Android Java project. The overlay is transparent and full-screen; the only visible element is a mouse pointer.

## Build with GitHub Actions
1. Upload all files/folders in this project to the root of a GitHub repository (do not upload only the ZIP).
2. Add the workflow below as `.github/workflows/android.yml`.
3. Open Actions and run **Build Invisible Touchpad APK**.
4. Download the APK artifact.

## Gestures
- One-finger drag: move pointer
- Single tap: left click (delayed briefly to detect double tap)
- Double tap: double click
- Two-finger tap: long-press approximation of a context click
- Two-finger vertical movement: scroll

## Important Android limitations
Android AccessibilityService can dispatch taps, long presses and swipes, but it does not expose a universal hardware-mouse right-click API. The two-finger tap therefore sends a long press; app behavior varies. Some secure/system screens may block overlays or injected gestures. This project is source code and has not been device-tested; validate on your Android device.
