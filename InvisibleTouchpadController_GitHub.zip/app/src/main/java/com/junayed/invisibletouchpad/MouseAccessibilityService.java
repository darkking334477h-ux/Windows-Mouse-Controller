package com.junayed.invisibletouchpad;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.view.accessibility.AccessibilityEvent;

public class MouseAccessibilityService extends AccessibilityService {
    public static volatile MouseAccessibilityService instance;

    @Override public void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }

    @Override public void onInterrupt() { }

    @Override public void onDestroy() {
        if (instance == this) instance = null;
        super.onDestroy();
    }

    public void tap(float x, float y) { gesture(x, y, x, y, 65); }

    public void doubleTap(float x, float y) {
        gesture(x, y, x, y, 55);
        new android.os.Handler(getMainLooper()).postDelayed(() -> gesture(x, y, x, y, 55), 120);
    }

    // Android has no universal accessibility "right-click" API.
    // A long press is used as the closest cross-app context-menu gesture.
    public void rightClickLikeLongPress(float x, float y) { gesture(x, y, x, y, 650); }

    public void scroll(float x, float y, float deltaY) {
        float endY = Math.max(2, Math.min(getResources().getDisplayMetrics().heightPixels - 2, y - deltaY));
        gesture(x, y, x, endY, 280);
    }

    private void gesture(float x1, float y1, float x2, float y2, long duration) {
        Path path = new Path();
        path.moveTo(x1, y1);
        path.lineTo(x2, y2);
        GestureDescription.StrokeDescription stroke =
            new GestureDescription.StrokeDescription(path, 0, duration);
        GestureDescription description = new GestureDescription.Builder().addStroke(stroke).build();
        dispatchGesture(description, null, null);
    }
}
