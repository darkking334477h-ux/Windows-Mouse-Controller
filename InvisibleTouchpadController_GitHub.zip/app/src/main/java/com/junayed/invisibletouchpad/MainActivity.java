package com.junayed.invisibletouchpad;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(28, 36, 28, 28);
        layout.setGravity(Gravity.CENTER_HORIZONTAL);

        TextView title = new TextView(this);
        title.setText("Invisible Touchpad");
        title.setTextSize(24);
        layout.addView(title);

        TextView info = new TextView(this);
        info.setText("প্রথমে Overlay ও Accessibility permission চালু করো। এরপর Start Touchpad চাপলে স্ক্রিনে শুধু Cursor থাকবে।");
        info.setTextSize(16);
        info.setPadding(0, 18, 0, 24);
        layout.addView(info);

        Button overlay = new Button(this);
        overlay.setText("1. Allow Overlay Permission");
        overlay.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } else Toast.makeText(this, "Overlay permission already allowed", Toast.LENGTH_SHORT).show();
        });
        layout.addView(overlay);

        Button accessibility = new Button(this);
        accessibility.setText("2. Enable Accessibility Service");
        accessibility.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        layout.addView(accessibility);

        Button start = new Button(this);
        start.setText("3. Start Invisible Touchpad");
        start.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "আগে Overlay permission দাও", Toast.LENGTH_LONG).show();
                return;
            }
            if (MouseAccessibilityService.instance == null) {
                Toast.makeText(this, "আগে Accessibility Service চালু করো", Toast.LENGTH_LONG).show();
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
                return;
            }
            startService(new Intent(this, MouseOverlayService.class));
            Toast.makeText(this, "Touchpad started. Stop করতে app আবার খুলে Stop চাপো।", Toast.LENGTH_LONG).show();
        });
        layout.addView(start);

        Button stop = new Button(this);
        stop.setText("Stop Touchpad");
        stop.setOnClickListener(v -> stopService(new Intent(this, MouseOverlayService.class)));
        layout.addView(stop);

        setContentView(layout);
    }
}
