package com.junayed.invisibletouchpad;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;

public class MouseOverlayService extends Service {
    private WindowManager wm;
    private PointerPad pad;
    private WindowManager.LayoutParams params;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private Runnable pendingSingle;
    private long lastTapTime;
    private float lastTapX, lastTapY;

    @Override public void onCreate() {
        super.onCreate();
        if (!android.provider.Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Overlay permission required", Toast.LENGTH_LONG).show();
            stopSelf(); return;
        }
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        pad = new PointerPad(this);
        params = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        wm.addView(pad, params);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) { return START_STICKY; }
    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public void onDestroy() {
        if (pendingSingle != null) handler.removeCallbacks(pendingSingle);
        if (pad != null && pad.isAttachedToWindow()) wm.removeView(pad);
        super.onDestroy();
    }

    private void setTouchable(boolean enabled) {
        if (pad == null || !pad.isAttachedToWindow()) return;
        params.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        if (!enabled) params.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        wm.updateViewLayout(pad, params);
    }

    private void sendGesture(Runnable action) {
        MouseAccessibilityService service = MouseAccessibilityService.instance;
        if (service == null) {
            Toast.makeText(this, "Accessibility Service চালু নেই", Toast.LENGTH_SHORT).show();
            return;
        }
        setTouchable(false);
        handler.postDelayed(() -> {
            action.run();
            handler.postDelayed(() -> setTouchable(true), 720);
        }, 35);
    }

    private void singleClick(float x, float y) {
        if (pendingSingle != null) handler.removeCallbacks(pendingSingle);
        pendingSingle = () -> {
            sendGesture(() -> {
                MouseAccessibilityService s = MouseAccessibilityService.instance;
                if (s != null) s.tap(x, y);
            });
            pendingSingle = null;
        };
        handler.postDelayed(pendingSingle, 260);
    }

    private void doubleClick(float x, float y) {
        if (pendingSingle != null) handler.removeCallbacks(pendingSingle);
        pendingSingle = null;
        sendGesture(() -> {
            MouseAccessibilityService s = MouseAccessibilityService.instance;
            if (s != null) s.doubleTap(x, y);
        });
    }

    private void rightClickLikeLongPress(float x, float y) {
        if (pendingSingle != null) handler.removeCallbacks(pendingSingle);
        pendingSingle = null;
        sendGesture(() -> {
            MouseAccessibilityService s = MouseAccessibilityService.instance;
            if (s != null) s.rightClickLikeLongPress(x, y);
        });
    }

    private void scrollAt(float x, float y, float dy) {
        sendGesture(() -> {
            MouseAccessibilityService s = MouseAccessibilityService.instance;
            if (s != null) s.scroll(x, y, dy);
        });
    }

    private class PointerPad extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private float cursorX = 220, cursorY = 420;
        private float downX, downY, lastX, lastY;
        private boolean moved, multi, scrolled;
        private float multiStartY;
        private int screenW, screenH;

        PointerPad(Context context) {
            super(context);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            // Use the actual overlay View size, not display metrics. On some
            // Android skins these values differ and can create a false boundary.
            screenW = 0;
            screenH = 0;
            setBackgroundColor(Color.TRANSPARENT);
        }

        @Override protected void onSizeChanged(int w, int h, int oldw, int oldh) {
            super.onSizeChanged(w, h, oldw, oldh);
            screenW = w;
            screenH = h;
            if (oldw == 0 || oldh == 0) {
                cursorX = Math.max(1, w * 0.5f);
                cursorY = Math.max(1, h * 0.5f);
            } else {
                cursorX = Math.max(1, Math.min(w - 28, cursorX));
                cursorY = Math.max(1, Math.min(h - 40, cursorY));
            }
            invalidate();
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            // Windows-like arrow cursor. Only this pointer is visible.
            Path p = new Path();
            p.moveTo(cursorX, cursorY);
            p.lineTo(cursorX, cursorY + 31);
            p.lineTo(cursorX + 8, cursorY + 23);
            p.lineTo(cursorX + 14, cursorY + 37);
            p.lineTo(cursorX + 20, cursorY + 34);
            p.lineTo(cursorX + 14, cursorY + 21);
            p.lineTo(cursorX + 26, cursorY + 21);
            p.close();

            paint.setColor(Color.WHITE);
            paint.setStyle(Paint.Style.FILL);
            canvas.drawPath(p, paint);
            paint.setColor(Color.BLACK);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(2.2f);
            canvas.drawPath(p, paint);
            paint.setStyle(Paint.Style.FILL);
        }

        @Override public boolean onTouchEvent(MotionEvent e) {
            int action = e.getActionMasked();
            switch (action) {
                case MotionEvent.ACTION_DOWN:
                    downX = lastX = e.getX();
                    downY = lastY = e.getY();
                    moved = multi = scrolled = false;
                    multiStartY = e.getY();
                    return true;

                case MotionEvent.ACTION_POINTER_DOWN:
                    multi = true;
                    multiStartY = averageY(e);
                    return true;

                case MotionEvent.ACTION_MOVE:
                    if (multi || e.getPointerCount() >= 2) {
                        float avg = averageY(e);
                        float delta = multiStartY - avg;
                        if (Math.abs(delta) > 10) {
                            scrolled = true;
                            multiStartY = avg;
                            scrollAt(cursorX + 8, cursorY + 18, delta * 2.4f);
                        }
                    } else {
                        float dx = e.getX() - lastX;
                        float dy = e.getY() - lastY;
                        if (Math.abs(e.getX() - downX) + Math.abs(e.getY() - downY) > 8) moved = true;
                        int actualW = getWidth();
                        int actualH = getHeight();
                        if (actualW > 0) screenW = actualW;
                        if (actualH > 0) screenH = actualH;
                        cursorX = Math.max(1, Math.min(Math.max(1, screenW - 28), cursorX + dx * 1.65f));
                        cursorY = Math.max(1, Math.min(Math.max(1, screenH - 40), cursorY + dy * 1.65f));
                        invalidate();
                    }
                    lastX = e.getX();
                    lastY = e.getY();
                    return true;

                case MotionEvent.ACTION_POINTER_UP:
                    return true;

                case MotionEvent.ACTION_UP:
                    if (multi) {
                        if (!scrolled) rightClickLikeLongPress(cursorX + 5, cursorY + 12);
                    } else if (!moved) {
                        long now = System.currentTimeMillis();
                        float dist = Math.abs(cursorX - lastTapX) + Math.abs(cursorY - lastTapY);
                        if (now - lastTapTime < 320 && dist < 45) {
                            doubleClick(cursorX + 5, cursorY + 12);
                            lastTapTime = 0;
                        } else {
                            singleClick(cursorX + 5, cursorY + 12);
                            lastTapTime = now;
                            lastTapX = cursorX;
                            lastTapY = cursorY;
                        }
                    }
                    return true;
            }
            return true;
        }

        private float averageY(MotionEvent e) {
            float sum = 0;
            for (int i = 0; i < e.getPointerCount(); i++) sum += e.getY(i);
            return sum / e.getPointerCount();
        }
    }
}
